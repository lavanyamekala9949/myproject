import React from "react";
import './day1.css';
import { useNavigate } from "react-router-dom";
const LoginPage=()=>{

    let n=useNavigate("")
    let Hom=()=>{
        n("/home")
    }
    let Sig=()=>{
        n("/")
    }


    return(
        <div>
            
        <table border></table>
                <div id="div1">
                 <form>   
                <center><h1 style={{color:"red"}}><i>DESIGN PRODUCT MANAGEMENT SYSTEM</i></h1><br></br>
            NAME:<input type="NAME" placeholder="enter name" required spacing={5}></input><br></br><br></br>
            GMAIL:<input type="GMAIL" placeholder="enter email" required spacing={5}></input><br></br><br></br>
            PASSWORD:<input type="PASSWORD" placeholder="enter password" required spacing={5}></input><br></br><br></br>
            <button onClick={Hom}><b>LOGIN</b></button><br></br><br></br>
            <a href="#">forgot password</a>
            <button onClick={Sig}><b>SignUp?</b></button>
            
            
            </center>
            </form>
        </div>
            </div>
    )
}
export default LoginPage;


