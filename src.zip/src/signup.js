import React from "react";
import './signup.css'
import { useNavigate } from "react-router-dom";

const SignUpPage=()=>{
    const n=useNavigate("")
    let submit=()=>{
        n("/login")
    }

    return(
        <center>
            <table border>
                        <div style={{border:"double"}} id="div9">
        <form>
           <u> <h1 style={{color:"violet"}}><b>WELCOME!!!</b></h1><br></br></u>
           <div style={{color:"blue"}}>
            Name:<input type="name" placeholder="enter name" required></input> <br></br><br></br><br></br><br></br>
            Gmail:<input type="Gmail" placeholder="enter email" required></input><br></br><br></br><br></br><br></br>
            Password:<input type="password" placeholder="enter password" required></input><br></br><br></br><br></br>
            <center><button variant="contained" onClick={submit}>SUBMIT</button></center>
            </div>
            </form>

        </div>
        </table>
        </center>
        
    )
}
export default SignUpPage;