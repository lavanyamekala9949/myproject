import React from "react";
import Path from "./PATHPAGE";
import LoginPage from "./day1";
import SignUpPage from "./signup";

function App(){
  return(
    <div>
      <Path/>
    </div>
  )
}
export default App;